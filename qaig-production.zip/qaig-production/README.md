# Qunbar Ali Islamic Guide — Hostinger Deployment Guide

## What's Inside This Package

```
qaig-production/
├── server/               ← Upload this entire folder to Hostinger
│   ├── dist/             ← Compiled Node.js server (do NOT edit)
│   ├── public/           ← Built React frontend (do NOT edit)
│   ├── package.json      ← Node.js app config
│   └── .env.example      ← Copy to .env and fill in your values
└── database/
    ├── schema.sql        ← Run FIRST — creates the tables
    └── seed.sql          ← Run SECOND — loads all 36 masail + 12 categories
```

---

## Step-by-Step Deployment on Hostinger

### Step 1 — Set Up a PostgreSQL Database

You need a PostgreSQL database. Options:

**Option A — Free external PostgreSQL (recommended for beginners):**
- Go to https://neon.tech → Sign up free → Create a project
- Copy the connection string (starts with `postgresql://...`)

**Option B — Hostinger VPS PostgreSQL:**
- SSH into your VPS and install PostgreSQL:
  ```bash
  sudo apt update && sudo apt install -y postgresql postgresql-contrib
  sudo -u postgres createuser --interactive
  sudo -u postgres createdb qaig_db
  ```

**Option C — Hostinger MySQL** *(not supported — this app requires PostgreSQL)*

---

### Step 2 — Create the Tables and Load Data

Connect to your PostgreSQL database and run the SQL files in order:

```bash
# Using psql command line:
psql "YOUR_DATABASE_URL" -f database/schema.sql
psql "YOUR_DATABASE_URL" -f database/seed.sql
```

Or paste the contents of each file into your database admin panel (e.g. pgAdmin, Neon console, Supabase SQL editor).

---

### Step 3 — Upload the Server Folder to Hostinger

1. Log in to Hostinger hPanel
2. Go to **Hosting → Manage → Node.js** (or VPS SSH)
3. Upload the entire `server/` folder contents to your Node.js app root directory

**Using File Manager or FTP:**
- Upload all files inside `server/` to your app root (e.g. `/home/user/domains/yourdomain.com/`)
- Make sure `dist/`, `public/`, and `package.json` are at the root level

**Using SSH/SCP:**
```bash
scp -r server/* user@your-server-ip:/home/user/domains/yourdomain.com/
```

---

### Step 4 — Set Environment Variables on Hostinger

In Hostinger hPanel → Node.js app settings, add these environment variables:

| Variable       | Value                                      |
|----------------|--------------------------------------------|
| `DATABASE_URL` | `postgresql://user:pass@host:5432/db_name` |
| `NODE_ENV`     | `production`                               |
| `PORT`         | `3000` (Hostinger may set this for you)    |

Alternatively, SSH into your server and create a `.env` file:
```bash
cd /home/user/domains/yourdomain.com/
cp .env.example .env
nano .env   # fill in your DATABASE_URL
```

---

### Step 5 — Install Dependencies and Start

SSH into your server:
```bash
cd /home/user/domains/yourdomain.com/
npm install --production
```

**Start the app:**
```bash
# Direct start:
node dist/index.mjs

# Using npm:
npm start

# Using PM2 (recommended for production — keeps app running):
npm install -g pm2
pm2 start dist/index.mjs --name "qaig"
pm2 save
pm2 startup   # auto-restart on server reboot
```

---

### Step 6 — Configure Your Domain

In Hostinger hPanel:
1. Go to **Domains → Manage → DNS**
2. Point your domain's A record to your server IP
3. In the Node.js app settings, set the entry point to `dist/index.mjs`
4. Set the port to `3000` (or whatever PORT you configured)

If using Nginx as a reverse proxy, add this to your Nginx config:
```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

---

## Admin Panel

- URL: `https://yourdomain.com/admin`
- Password: `admin123`
- Use the admin panel to add, edit, or delete masail and categories
- **Change the password** after going live: go to `/admin`, log in, and update the password in Local Storage key `adminPassword`

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| App won't start | Check `DATABASE_URL` is set correctly and PostgreSQL is reachable |
| "Cannot find module" error | Run `npm install --production` in the server folder |
| Blank page / 404 | Make sure the `public/` folder is inside the server root |
| Database connection refused | Check firewall rules — port 5432 must be open between app and DB server |
| PORT already in use | Change `PORT` env variable to `3001` or another free port |

---

## Technical Details

- **Backend:** Node.js + Express 5 (compiled, no TypeScript needed on server)
- **Frontend:** React + Vite (pre-built static files, served by Express)
- **Database:** PostgreSQL with Drizzle ORM
- **Node.js version required:** 18 or higher
- **Single process:** One Node.js process serves both the API and the frontend

---

*Built with ❤️ — Qunbar Ali Islamic Guide*
