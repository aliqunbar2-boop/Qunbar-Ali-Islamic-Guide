-- ============================================================
-- Qunbar Ali Islamic Guide — Database Schema
-- Run this FIRST to create the tables, then run seed.sql
-- Compatible with PostgreSQL 13+
-- ============================================================

CREATE TABLE IF NOT EXISTS categories (
  id          SERIAL PRIMARY KEY,
  name        TEXT NOT NULL,
  name_urdu   TEXT NOT NULL,
  slug        TEXT NOT NULL UNIQUE,
  description TEXT,
  created_at  TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS masail (
  id            SERIAL PRIMARY KEY,
  question      TEXT NOT NULL,
  question_urdu TEXT NOT NULL,
  answer        TEXT NOT NULL,
  answer_urdu   TEXT NOT NULL,
  category_id   INTEGER NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
  reference     TEXT NOT NULL,
  created_at    TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS masail_category_id_idx ON masail(category_id);
CREATE INDEX IF NOT EXISTS masail_created_at_idx  ON masail(created_at DESC);
